package com.example.cacse226

class RecyclerViewAdapter(cricketerList: ArrayList<CricketerData>) {
}