package com.example.cacse226

import android.annotation.SuppressLint
import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView

class Cricketer:AppCompatActivity() {
    private lateinit var rv: RecyclerView
    private lateinit var cricketerList: ArrayList<CricketerData>
    private lateinit var adpt: RecyclerViewAdapter
    @SuppressLint("MissingInflatedId")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_cricketer)
        rv = findViewById(R.id.idrv)
        rv.setHasFixedSize(true)
        rv.layoutManager = LinearLayoutManager(this)
        cricketerList = ArrayList()
        adpt = RecyclerViewAdapter(cricketerList)
        rv.adapter = adpt
        addData()
    }
    private fun addData() {
        cricketerList.add(CricketerData("Virat Kohli", "6624", "223"))
        cricketerList.add(CricketerData("Rohit Sharma", "5880", "227"))
        cricketerList.add(CricketerData("MS Dhoni", "4842", "204"))
        cricketerList.add(CricketerData("KL Rahul", "3932", "109"))
        cricketerList.add(CricketerData("Shikhar Dhawan", "6244", "206"))
    }

}

