package com.example.cacse226

class CricketerData(s: String, s1: String, s2: String) {
    var name: String? = null
    var totalRuns: String? = null
    var totalMatches: String? = null
}